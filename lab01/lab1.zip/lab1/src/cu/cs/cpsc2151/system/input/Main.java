// Eric Switzer, Andrew Hunter
package cu.cs.cpsc2151.system.input;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enter integer: ");
		
		Scanner scanner = new Scanner(System.in);
		String input = scanner.next();
		scanner.close();
		
		System.out.print("Containing 7:");
		
		int counter = 0;
		
		for(int i = 0; i < 10; counter++) {
			String stringInput = String.valueOf(counter);
			if(stringInput.contains(input)) {
				i++;
				System.out.print(" " + stringInput);
			}
		}
		
	}

}
