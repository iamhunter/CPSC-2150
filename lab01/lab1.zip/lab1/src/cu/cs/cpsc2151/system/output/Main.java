// Eric Switzer, Andrew Hunter
package cu.cs.cpsc2151.system.output;

public class Main {

	public static void main(String[] args) {
		System.out.println("Section 5");
	}

}
