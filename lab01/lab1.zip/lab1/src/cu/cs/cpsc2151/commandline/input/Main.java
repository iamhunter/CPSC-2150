// Eric Switzer, Andrew Hunter
package cu.cs.cpsc2151.commandline.input;

public class Main {
	
	public static void main(String[] args) {
		int sum = 0; 
		System.out.print("Arguments:");
		for(int x = 0; x < args.length; ++x) {
			System.out.print(" " + args[x]);
			sum += Integer.parseInt(args[x]);
		}
		System.out.println();
		System.out.println("Sum: " + sum);
	}

}
